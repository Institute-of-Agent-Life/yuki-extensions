"""emoji package."""
